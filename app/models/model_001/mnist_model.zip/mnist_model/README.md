# Assumptions
- Make sure port 8000 is free
# How to run
- run:
```
sudo chmod +x ./run_model.sh
./run_model.sh
```
This sets up pytorch runtime and automatically runs the backend.
in the terminal and access ui via frontend.html
