import io
import os
import torch
from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image
from torchvision import transforms
from torch import nn

# Create the FastAPI app
app = FastAPI()

# Allow all CORS requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Accept requests from any origin
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Define the ImageClassifier model (must match the architecture used during training)
class ImageClassifier(nn.Module):
    def __init__(self):
        super(ImageClassifier, self).__init__()
        self.conv_layers = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=3),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3),
            nn.ReLU()
        )
        self.fc_layers = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 22 * 22, 10)
        )

    def forward(self, x):
        x = self.conv_layers(x)
        x = self.fc_layers(x)
        return x

# Set up device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Initialize and load the model
classifier = ImageClassifier().to(device)
state_dict = torch.load("model_state.pt", map_location=device)

# Fix key mismatches from the saved state_dict if necessary
new_state_dict = {}
for key in state_dict.keys():
    if key.startswith("model.0"):
        new_key = key.replace("model.0", "conv_layers.0")
    elif key.startswith("model.2"):
        new_key = key.replace("model.2", "conv_layers.2")
    elif key.startswith("model.4"):
        new_key = key.replace("model.4", "conv_layers.4")
    elif key.startswith("model.7"):
        new_key = key.replace("model.7", "fc_layers.1")
    else:
        new_key = key
    new_state_dict[new_key] = state_dict[key]

classifier.load_state_dict(new_state_dict, strict=True)
classifier.eval()

# Define the image transformation to match the training pipeline
transform = transforms.Compose([
    transforms.Grayscale(num_output_channels=1),  # Convert image to grayscale
    transforms.Resize((28, 28)),                   # Resize to 28x28 pixels
    transforms.ToTensor(),                         # Convert to tensor and scale pixel values
])

@app.post("/infer")
async def predict(image: UploadFile = File(...)):
    """
    Receives an image file and returns the predicted label.
    """
    # Read the file contents and open it as an image
    contents = await image.read()
    try:
        pil_image = Image.open(io.BytesIO(contents))
    except Exception as e:
        return {"error": "Could not open image. Please upload a valid image file."}

    # Apply the transformation and add a batch dimension
    input_tensor = transform(pil_image).unsqueeze(0).to(device)
    
    # Run inference
    with torch.no_grad():
        output = classifier(input_tensor)
        predicted_label = torch.argmax(output, dim=1).item()
    
    # Return the result as JSON
    return {"predicted_label": predicted_label}

if __name__ == "__main__":
    import uvicorn
    # Run the app with uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
